package constants;

public class SheetNames {

	public static final String SHEET_NAME              = "NamesAndJobs";
	
}
